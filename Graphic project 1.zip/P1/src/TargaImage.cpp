///////////////////////////////////////////////////////////////////////////////
//
//      TargaImage.cpp                          Author:     Stephen Chenney
//                                              Modified:   Eric McDaniel
//                                              Date:       Fall 2004
//
//      Implementation of TargaImage methods.  You must implement the image
//  modification functions.
//
///////////////////////////////////////////////////////////////////////////////

#include "Globals.h"
#include "TargaImage.h"
#include "libtarga.h"
#include <stdlib.h>
#include <assert.h>
#include <memory.h>
#include <math.h>
#include <iostream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <random>
#include <string>


using namespace std;

// constants
const int           RED             = 0;                // red channel
const int           GREEN           = 1;                // green channel
const int           BLUE            = 2;                // blue channel
const unsigned char BACKGROUND[3]   = { 0, 0, 0 };      // background color


// Computes n choose s, efficiently
double Binomial(int n, int s)
{
    double        res;

    res = 1;
    for (int i = 1 ; i <= s ; i++)
        res = (n - i + 1) * res / i ;

    return res;
}// Binomial


///////////////////////////////////////////////////////////////////////////////
//
//      Constructor.  Initialize member variables.
//
///////////////////////////////////////////////////////////////////////////////
TargaImage::TargaImage() : width(0), height(0), data(NULL)
{}// TargaImage

///////////////////////////////////////////////////////////////////////////////
//
//      Constructor.  Initialize member variables.
//
///////////////////////////////////////////////////////////////////////////////
TargaImage::TargaImage(int w, int h) : width(w), height(h)
{
   data = new unsigned char[width * height * 4];
   ClearToBlack();
}// TargaImage



///////////////////////////////////////////////////////////////////////////////
//
//      Constructor.  Initialize member variables to values given.
//
///////////////////////////////////////////////////////////////////////////////
TargaImage::TargaImage(int w, int h, unsigned char *d)
{
    int i;

    width = w;
    height = h;
    data = new unsigned char[width * height * 4];

    for (i = 0; i < width * height * 4; i++)
	    data[i] = d[i];
}// TargaImage

///////////////////////////////////////////////////////////////////////////////
//
//      Copy Constructor.  Initialize member to that of input
//
///////////////////////////////////////////////////////////////////////////////
TargaImage::TargaImage(const TargaImage& image) 
{
   width = image.width;
   height = image.height;
   data = NULL; 
   if (image.data != NULL) {
      data = new unsigned char[width * height * 4];
      memcpy(data, image.data, sizeof(unsigned char) * width * height * 4);
   }
}


///////////////////////////////////////////////////////////////////////////////
//
//      Destructor.  Free image memory.
//
///////////////////////////////////////////////////////////////////////////////
TargaImage::~TargaImage()
{
    if (data)
        delete[] data;
}// ~TargaImage


///////////////////////////////////////////////////////////////////////////////
//
//      Converts an image to RGB form, and returns the rgb pixel data - 24 
//  bits per pixel. The returned space should be deleted when no longer 
//  required.
//
///////////////////////////////////////////////////////////////////////////////
unsigned char* TargaImage::To_RGB(void)
{
    unsigned char   *rgb = new unsigned char[width * height * 3];
    int		    i, j;

    if (! data)
	    return NULL;

    // Divide out the alpha
    for (i = 0 ; i < height ; i++)
    {
	    int in_offset = i * width * 4;
	    int out_offset = i * width * 3;

	    for (j = 0 ; j < width ; j++)
        {
	        RGBA_To_RGB(data + (in_offset + j*4), rgb + (out_offset + j*3));
	    }
    }

    return rgb;
}// TargaImage


///////////////////////////////////////////////////////////////////////////////
//
//      Save the image to a targa file. Returns 1 on success, 0 on failure.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::Save_Image(const char *filename)
{
    TargaImage	*out_image = Reverse_Rows();

    if (! out_image)
	    return false;

    if (!tga_write_raw(filename, width, height, out_image->data, TGA_TRUECOLOR_32))
    {
	    cout << "TGA Save Error: %s\n", tga_error_string(tga_get_last_error());
	    return false;
    }



    delete out_image;

    return true;
}// Save_Image


///////////////////////////////////////////////////////////////////////////////
//
//      Load a targa image from a file.  Return a new TargaImage object which 
//  must be deleted by caller.  Return NULL on failure.
//
///////////////////////////////////////////////////////////////////////////////
TargaImage* TargaImage::Load_Image(char *filename)
{
    unsigned char   *temp_data;
    TargaImage	    *temp_image;
    TargaImage	    *result;
    int		        width, height;

    if (!filename)
    {
        cout << "No filename given." << endl;
        return NULL;
    }// if

    temp_data = (unsigned char*)tga_load(filename, &width, &height, TGA_TRUECOLOR_32);
    if (!temp_data)
    {
        cout << "TGA Error: %s\n", tga_error_string(tga_get_last_error());
	    width = height = 0;
	    return NULL;
    }
    temp_image = new TargaImage(width, height, temp_data);
    free(temp_data);

    result = temp_image->Reverse_Rows();

    delete temp_image;

    return result;
}// Load_Image


///////////////////////////////////////////////////////////////////////////////
//
//      Convert image to grayscale.  Red, green, and blue channels should all 
//  contain grayscale value.  Alpha channel shoould be left unchanged.  Return
//  success of operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::To_Grayscale()
{
    if (!data) return NULL;

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            int newGrayColor = 0.30 * data[i * width * 4 + j * 4] + 0.59 * data[i * width * 4 + j * 4 + 1] + 0.11 * data[i * width * 4 + j * 4 + 2];
            data[i * width * 4 + j * 4] = newGrayColor;
            data[i * width * 4 + j * 4 + 1] = newGrayColor;
            data[i * width * 4 + j * 4 + 2] = newGrayColor;
        }
    }

    return true;

}// To_Grayscale


///////////////////////////////////////////////////////////////////////////////
//
//  Convert the image to an 8 bit image using uniform quantization.  Return 
//  success of operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::Quant_Uniform()
{
    
    if (!data) return NULL;

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            int newRed = data[i * width * 4 + j * 4] / 32;
            data[i * width * 4 + j * 4] = newRed * 32 ;
            int newGreen = data[i * width * 4 + j * 4 + 1] / 32;
            data[i * width * 4 + j * 4 + 1] =  newGreen * 32;
            int newBlue = data[i * width * 4 + j * 4 + 2] / 64;
            data[i * width * 4 + j * 4 + 2] = newBlue * 64 ;
        }
    }
    
    return true;
}// Quant_Uniform


///////////////////////////////////////////////////////////////////////////////
//
//      Convert the image to an 8 bit image using populosity quantization.  
//  Return success of operation.
//
///////////////////////////////////////////////////////////////////////////////

struct colors {
    int number;
    int count;
};

bool quantPopuCompare(colors c1,colors c2)
{
    return c1.count > c2.count;
}


bool TargaImage::Quant_Populosity()
{

    if (!data) return NULL;

    vector<colors> numbers;

    for (int r = 0; r < 32; r++)
    {
        for (int g = 0; g < 32; g++)
        {
            for (int b = 0; b < 32; b++)
            {
                colors c;
                c.number = r * 10000 + g * 100 + b;
                c.count = 0;
                numbers.push_back(c);
            }
        }
    }


    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            int numberNo;
            int newRed = data[i * width * 4 + j * 4] / 8;
            data[i * width * 4 + j * 4] /= 8;
            numberNo = newRed * 10000;
            int newGreen = data[i * width * 4 + j * 4 + 1] / 8;
            data[i * width * 4 + j * 4 + 1] /= 8;
            numberNo += newGreen * 100;
            int newBlue = data[i * width * 4 + j * 4 + 2] / 8;
            data[i * width * 4 + j * 4 + 2] /= 8;
            numberNo += newBlue;
            
            for (int n = 0; n < numbers.size(); n++)
            {
                if (numberNo == numbers[n].number)
                {
                    numbers[n].count += 1;
                    break;
                }
            }

        }
    }

    sort(numbers.begin(), numbers.end(), quantPopuCompare);

    vector<int> choose;

    // �̦h�����C��
    for (int i = 0; i < 256; i++)
    {
        choose.push_back(numbers[i].number);
    }

    // ���L�C����
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            int minLen = 100000000000000000;
            bool match = 0;
            int R = 0, G = 0, B = 0;
            for (int k = 0; k < choose.size(); k++)
            {
                int r = choose[k] / 10000;
                int g = (choose[k] % 10000) / 100;
                int b = (choose[k] % 10000) % 100;

                int length = (r - data[i * width * 4 + j * 4]) * (r - data[i * width * 4 + j * 4]) +
                    (g - data[i * width * 4 + j * 4 + 1]) * (g - data[i * width * 4 + j * 4 + 1]) +
                    (b - data[i * width * 4 + j * 4 + 2]) * (b - data[i * width * 4 + j * 4 + 2]);

                if (r == data[i * width * 4 + j * 4] && g == data[i * width * 4 + j * 4 + 1] && b == data[i * width * 4 + j * 4 + 2])
                {
                    data[i * width * 4 + j * 4] *= 8;
                    data[i * width * 4 + j * 4 + 1] *= 8;
                    data[i * width * 4 + j * 4 + 2] *= 8;
                    match = 1;
                    break;
                }
                else if (minLen >= length)
                {
                    minLen = length;
                    R = r * 8;
                    G = g * 8;
                    B = b * 8;
                }
            }

            if (match == 0)
            {
                data[i * width * 4 + j * 4] = (int)R;
                data[i * width * 4 + j * 4 + 1] = (int)G;
                data[i * width * 4 + j * 4 + 2] = (int)B;
            }
        }
    }

    return true;
}// Quant_Populosity


///////////////////////////////////////////////////////////////////////////////
//
//      Dither the image using a threshold of 1/2.  Return success of operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::Dither_Threshold()
{
    
    To_Grayscale();

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            double grayNum = data[i * width * 4 + j * 4] / 255.0;

            if (grayNum >= 0.5)
            {
                data[i * width * 4 + j * 4] = 255;
                data[i * width * 4 + j * 4 + 1] = 255;
                data[i * width * 4 + j * 4 + 2] = 255;
            }
            else
            {
                data[i * width * 4 + j * 4] = 0;
                data[i * width * 4 + j * 4 + 1] = 0;
                data[i * width * 4 + j * 4 + 2] = 0;
            }
        }
    }

    return true;

}// Dither_Threshold


///////////////////////////////////////////////////////////////////////////////
//
//      Dither image using random dithering.  Return success of operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::Dither_Random()
{
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<> dis(-0.2, 0.2);

    To_Grayscale();

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            double grayNum = data[i * width * 4 + j * 4] / 255.0;
            double num = dis(gen);
            if (grayNum + num > 1)
            {
                grayNum = 1;
            }
            else if (grayNum + num < 0)
            {
                grayNum = 0;
            }
            else
            {
                grayNum += num;
            }

            if (grayNum >= 0.5)
            {
                data[i * width * 4 + j * 4] = 255;
                data[i * width * 4 + j * 4 + 1] = 255;
                data[i * width * 4 + j * 4 + 2] = 255;
            }
            else
            {
                data[i * width * 4 + j * 4] = 0;
                data[i * width * 4 + j * 4 + 1] = 0;
                data[i * width * 4 + j * 4 + 2] = 0;
            }
        }
    }

    return true;
}// Dither_Random


///////////////////////////////////////////////////////////////////////////////
//
//      Perform Floyd-Steinberg dithering on the image.  Return success of 
//  operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::Dither_FS()
{
    To_Grayscale();

    int count = 0;
    int i = 0;
    int j = 0;
    int grayNum = 0;
    double e = 0.0;
    int direction = 1;

    while (count < height * width)
    {

        grayNum = data[i * width * 4 + j * 4] / 255.0 >= 0.5 ? 1 : 0;

        if (grayNum == 1)
        {
            e = data[i * width * 4 + j * 4] / 255.0 - 1.0;
            data[i * width * 4 + j * 4] = 255;
            data[i * width * 4 + j * 4 + 1] = 255;
            data[i * width * 4 + j * 4 + 2] = 255;

        }
        else
        {
            e = data[i * width * 4 + j * 4] / 255.0;
            data[i * width * 4 + j * 4] = 0;
            data[i * width * 4 + j * 4 + 1] = 0;
            data[i * width * 4 + j * 4 + 2] = 0;
        }

        if (j + 1 < width && j > 0)
        {
            if (data[i * width * 4 + (j + direction) * 4] + (e * 7.0 / 16.0) * 255.0 >= 255)
            {
                data[i * width * 4 + (j + direction) * 4] = 255;
            }
            else if (data[i * width * 4 + (j + direction) * 4] + (e * 7.0 / 16.0) * 255.0 <= 0)
            {
                data[i * width * 4 + (j + direction) * 4] = 0;
            }
            else
            {
                data[i * width * 4 + (j + direction) * 4] += (e * 7.0 / 16.0) * 255.0;
            }
        }

        
        if (i + 1 < height && j + 1 < width && j > 0)
        {
            if (data[(i + 1) * width * 4 + (j + direction) * 4] + (e * 1.0 / 16.0) * 255.0 >= 255)
            {
                data[(i + 1) * width * 4 + (j + direction) * 4] = 255;
            }
            else if (data[(i + 1) * width * 4 + (j + direction) * 4] + (e * 1.0 / 16.0) * 255.0 <= 0)
            {
                data[(i + 1) * width * 4 + (j + direction) * 4] = 0;
            }
            else
            {
                data[(i + 1) * width * 4 + (j + direction) * 4] += (e * 1.0 / 16.0) * 255.0;
            }
        }

        if (i + 1 < height)
        {
            if (data[(i + 1) * width * 4 + j * 4] + (e * 5.0 / 16.0) * 255.0 >= 255)
            {
                data[(i + 1) * width * 4 + j * 4] = 255;
            }
            else if (data[(i + 1) * width * 4 + j * 4] + (e * 5.0 / 16.0) * 255.0 <= 0)
            {
                data[(i + 1) * width * 4 + j * 4] = 0;
            }
            else
            {
                data[(i + 1) * width * 4 + j * 4] += (e * 5.0 / 16.0) * 255.0;
            }
        }
        if (j > 0 && i + 1 < height && j + 1 < width)
        {
            if (data[(i + 1) * width * 4 + (j - direction) * 4] + (e * 3.0 / 16.0) * 255.0 >= 255)
            {
                data[(i + 1) * width * 4 + (j - direction) * 4] = 255;
            }
            else if (data[(i + 1) * width * 4 + (j - direction) * 4] + (e * 3.0 / 16.0) * 255.0 <= 0)
            {
                data[(i + 1) * width * 4 + (j - direction) * 4] = 0;
            }
            else
            {
                data[(i + 1) * width * 4 + (j - direction) * 4] += (e * 3.0 / 16.0) * 255.0;
            }
            
        }


        
        if ((count + 1) % width == 0)
        {
            int countTime = (count + 1) / width;
            if (countTime % 2 == 1)
            {
                direction = -1;
            }
            else
            {
                direction = 1;
            }
            if (i != height - 1)
            {
                i += 1;
            }
        }
        else
        {
            j += direction;
        }

        count += 1;
    }

    
    return true;
}// Dither_FS


///////////////////////////////////////////////////////////////////////////////
//
//      Dither the image while conserving the average brightness.  Return 
//  success of operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::Dither_Bright()
{
    vector<double> grayNums;

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            double grayColor = 0.30 * data[i * width * 4 + j * 4] + 0.59 * data[i * width * 4 + j * 4 + 1] + 0.11 * data[i * width * 4 + j * 4 + 2];
            double grayNum = grayColor / 255.0;
            grayNums.push_back(grayNum); 
        }
    }

    double sum = 0.0;
    for (int i = 0; i < grayNums.size(); i++)
    {
        sum += grayNums[i];
    }

    sum /= grayNums.size();

    int place = (1 - sum) * grayNums.size();

    sort(grayNums.begin(), grayNums.end());

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            double grayColor = 0.30 * data[i * width * 4 + j * 4] + 0.59 * data[i * width * 4 + j * 4 + 1] + 0.11 * data[i * width * 4 + j * 4 + 2];
            double grayNum = grayColor / 255.0;

            if (grayNum >= grayNums[place])
            {
                data[i * width * 4 + j * 4] = 255;
                data[i * width * 4 + j * 4 + 1] = 255;
                data[i * width * 4 + j * 4 + 2] = 255;
            }
            else
            {
                data[i * width * 4 + j * 4] = 0;
                data[i * width * 4 + j * 4 + 1] = 0;
                data[i * width * 4 + j * 4 + 2] = 0;
            }
        }
    }


    return true;
}// Dither_Bright


///////////////////////////////////////////////////////////////////////////////
//
//      Perform clustered differing of the image.  Return success of operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::Dither_Cluster()
{
    To_Grayscale();

    double matrix[][4] = { {0.7059, 0.3529, 0.5882, 0.2353},
                           {0.0588, 0.9412, 0.8235, 0.4118},
                           {0.4706, 0.7647, 0.8824, 0.1176},
                           {0.1765, 0.5294, 0.2941, 0.6471} };

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            double grayNum = data[i * width * 4 + j * 4] / 255.0;

            if (grayNum >= matrix[i % 4][j % 4])
            {
                data[i * width * 4 + j * 4] = 255;
                data[i * width * 4 + j * 4 + 1] = 255;
                data[i * width * 4 + j * 4 + 2] = 255;
            }
            else
            {
                data[i * width * 4 + j * 4] = 0;
                data[i * width * 4 + j * 4 + 1] = 0;
                data[i * width * 4 + j * 4 + 2] = 0;
            }
        }
    }

    return true;
}// Dither_Cluster


///////////////////////////////////////////////////////////////////////////////
//
//  Convert the image to an 8 bit image using Floyd-Steinberg dithering over
//  a uniform quantization - the same quantization as in Quant_Uniform.
//  Return success of operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::Dither_Color()
{
    int count = 0;
    int i = 0;
    int j = 0;
    double rE, gE, bE;
    double newR = 0, newG = 0, newB = 0;
    double rDis, gDis, bDis;

    double rg[8] = { 0.0, 36.0, 73.0, 109.0, 146.0, 182.0, 219.0, 255.0 };
    double b[4] = { 0.0, 85.0, 170.0, 255.0 };

    int direction = 1;

    while (count < height * width)
    {
        rDis = 100000000;
        gDis = 100000000;
        bDis = 100000000;

        newR = 0.0;
        newG = 0.0;
        newB = 0.0;

        for (int m = 0; m < 8; m++)
        {
            if (rDis > pow(data[i * width * 4 + j * 4] - rg[m], 2))
            {
                rDis = pow(data[i * width * 4 + j * 4] - rg[m], 2);
                newR = rg[m];
                rE = data[i * width * 4 + j * 4] - rg[m];
            }
            if (gDis > pow(data[i * width * 4 + j * 4 + 1] - rg[m], 2))
            {
                gDis = pow(data[i * width * 4 + j * 4 + 1] - rg[m], 2);
                newG = rg[m];
                gE = data[i * width * 4 + j * 4 + 1] - rg[m];
            }
        }

        for (int n = 0; n < 4; n++)
        {
            if (bDis > pow(data[i * width * 4 + j * 4 + 2] - b[n], 2))
            {
                bDis = pow(data[i * width * 4 + j * 4 + 2] - b[n], 2);
                newB = b[n];
                bE = data[i * width * 4 + j * 4 + 2] - b[n];
            }
        }

        data[i * width * 4 + j * 4] = newR;
        data[i * width * 4 + j * 4 + 1] = newG;
        data[i * width * 4 + j * 4 + 2] = newB;

        if (j + 1 < width && j > 0)
        {
            
            if (data[i * width * 4 + (j + direction) * 4] + rE * 7.0 / 16.0 >= 255 || data[i * width * 4 + (j + direction) * 4] + rE * 7.0 / 16.0 <= 0)
            {
                data[i * width * 4 + (j + direction) * 4] = data[i * width * 4 + (j + direction) * 4] + rE * 7.0 / 16.0 >= 255 ? 255 : 0;
            }
            else
            {
                data[i * width * 4 + (j + direction) * 4] += rE * 7.0 / 16.0;
            }

            if (data[i * width * 4 + (j + direction) * 4 + 1] + gE * 7.0 / 16.0 >= 255 || data[i * width * 4 + (j + direction) * 4 + 1] + gE * 7.0 / 16.0 <= 0)
            {
                data[i * width * 4 + (j + direction) * 4 + 1] = data[i * width * 4 + (j + direction) * 4 + 1] + gE * 7.0 / 16.0 >= 255 ? 255 : 0;
            }
            else
            {
                data[i * width * 4 + (j + direction) * 4 + 1] += gE * 7.0 / 16.0;
            }

            if (data[i * width * 4 + (j + direction) * 4 + 2] + bE * 7.0 / 16.0 >= 255 || data[i * width * 4 + (j + direction) * 4 + 2] + bE * 7.0 / 16.0 <= 0)
            {
                data[i * width * 4 + (j + direction) * 4 + 2] = data[i * width * 4 + (j + direction) * 4 + 2] + bE * 7.0 / 16.0 >= 255 ? 255 : 0;
            }
            else
            {
                data[i * width * 4 + (j + direction) * 4 + 2] += bE * 7.0 / 16.0;
            }
        }

        if (i + 1 < height && j + 1 < width && j > 0)
        {    
            if (data[(i + 1) * width * 4 + (j + direction) * 4] + rE * 1.0 / 16.0 >= 255 || data[(i + 1) * width * 4 + (j + direction) * 4] + rE * 1.0 / 16.0 <= 0)
            {
                data[(i + 1) * width * 4 + (j + direction) * 4] = data[(i + 1) * width * 4 + (j + direction) * 4] + rE * 1.0 / 16.0 >= 255 ? 255 : 0;
            }
            else
            {
                data[(i + 1) * width * 4 + (j + direction) * 4] += rE * 1.0 / 16.0;
            }

            if (data[(i + 1) * width * 4 + (j + direction) * 4 + 1] + gE * 1.0 / 16.0 >= 255 || data[(i + 1) * width * 4 + (j + direction) * 4 + 1] + gE * 1.0 / 16.0 <= 0)
            {
                data[(i + 1) * width * 4 + (j + direction) * 4 + 1] = data[(i + 1) * width * 4 + (j + direction) * 4 + 1] + gE * 1.0 / 16.0 >= 255 ? 255 : 0;
            }
            else
            {
                data[(i + 1) * width * 4 + (j + direction) * 4 + 1] += gE * 1.0 / 16.0;
            }

            if (data[(i + 1) * width * 4 + (j + direction) * 4 + 2] + bE * 1.0 / 16.0 >= 255 || data[(i + 1) * width * 4 + (j + direction) * 4 + 2] + bE * 1.0 / 16.0 <= 0)
            {
                data[(i + 1) * width * 4 + (j + direction) * 4 + 2] = data[(i + 1) * width * 4 + (j + direction) * 4 + 2] + bE * 1.0 / 16.0 >= 255 ? 255 : 0;
            }
            else
            {
                data[(i + 1) * width * 4 + (j + direction) * 4 + 2] += bE * 1.0 / 16.0;
            }

        }

        if (i + 1 < height)
        {
            if (data[(i + 1) * width * 4 + j * 4] + rE * 5.0 / 16.0 >= 255 || data[(i + 1) * width * 4 + j * 4] + rE * 5.0 / 16.0 <= 0)
            {
                data[(i + 1) * width * 4 + j * 4] = data[(i + 1) * width * 4 + j * 4] + rE * 5.0 / 16.0 >= 255 ? 255 : 0;
            }
            else
            {
                data[(i + 1) * width * 4 + j * 4] += rE * 5.0 / 16.0;
            }

            if (data[(i + 1) * width * 4 + j * 4 + 1] + gE * 5.0 / 16.0 >= 255 || data[(i + 1) * width * 4 + j * 4 + 1] + gE * 5.0 / 16.0 <= 0)
            {
                data[(i + 1) * width * 4 + j * 4 + 1] = data[(i + 1) * width * 4 + j * 4 + 1] + gE * 5.0 / 16.0 >= 255 ? 255 : 0;
            }
            else
            {
                data[(i + 1) * width * 4 + j * 4 + 1] += gE * 5.0 / 16.0;
            }

            if (data[(i + 1) * width * 4 + j * 4 + 2] + bE * 5.0 / 16.0 >= 255 || data[(i + 1) * width * 4 + j * 4 + 2] + bE * 5.0 / 16.0 <= 0)
            {
                data[(i + 1) * width * 4 + j * 4 + 2] = data[(i + 1) * width * 4 + j * 4 + 2] + bE * 5.0 / 16.0 >= 255 ? 255 : 0;
            }
            else
            {
                data[(i + 1) * width * 4 + j * 4 + 2] += bE * 5.0 / 16.0;
            }

        }

        if (j > 0 && i + 1 < height && j + 1 < width )
        { 
            if (data[(i + 1) * width * 4 + (j - direction) * 4] + rE * 3.0 / 16.0 >= 255 || data[(i + 1) * width * 4 + (j - direction) * 4] + rE * 3.0 / 16.0 <= 0)
            {
                data[(i + 1) * width * 4 + (j - direction) * 4] = data[(i + 1) * width * 4 + (j - direction) * 4] + rE * 3.0 / 16.0 >= 255 ? 255 : 0;
            }
            else
            {
                data[(i + 1) * width * 4 + (j - direction) * 4] += rE * 3.0 / 16.0;
            }

            if (data[(i + 1) * width * 4 + (j - direction) * 4 + 1] + gE * 3.0 / 16.0 >= 255 || data[(i + 1) * width * 4 + (j - direction) * 4 + 1] + gE * 3.0 / 16.0 <= 0)
            {
                data[(i + 1) * width * 4 + (j - direction) * 4 + 1] = data[(i + 1) * width * 4 + (j - direction) * 4 + 1] + gE * 3.0 / 16.0 >= 255 ? 255 : 0;
            }
            else
            {
                data[(i + 1) * width * 4 + (j - direction) * 4 + 1] += gE * 3.0 / 16.0;
            }

            if (data[(i + 1) * width * 4 + (j - direction) * 4 + 2] + bE * 3.0 / 16.0 >= 255 || data[(i + 1) * width * 4 + (j - direction) * 4 + 2] + bE * 3.0 / 16.0 <= 0)
            {
                data[(i + 1) * width * 4 + (j - direction) * 4 + 2] = data[(i + 1) * width * 4 + (j - direction) * 4 + 2] + bE * 3.0 / 16.0 >= 255 ? 255 : 0;
            }
            else
            {
                data[(i + 1) * width * 4 + (j - direction) * 4 + 2] += bE * 3.0 / 16.0;
            }
        }


        if ((count + 1) % width == 0)
        {
            int countTime = (count + 1) / width;
            if (countTime % 2 == 1)
            {
                direction = -1;
            }
            else
            {
                direction = 1;
            }
            if (i != height - 1)
            {
                i += 1;
            }
        }
        else
        {
            j += direction;
        }


        if (j < 0 || j > width - 1)
        {
            cout << "wrong" << endl;
        }
        count += 1;

    }

    return true;
}// Dither_Color


///////////////////////////////////////////////////////////////////////////////
//
//      Composite the current image over the given image.  Return success of 
//  operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::Comp_Over(TargaImage* pImage)
{
    if (width != pImage->width || height != pImage->height)
    {
        cout <<  "Comp_Over: Images not the same size\n";
        return false;
    }

    ClearToBlack();
    return false;
}// Comp_Over


///////////////////////////////////////////////////////////////////////////////
//
//      Composite this image "in" the given image.  See lecture notes for 
//  details.  Return success of operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::Comp_In(TargaImage* pImage)
{
    if (width != pImage->width || height != pImage->height)
    {
        cout << "Comp_In: Images not the same size\n";
        return false;
    }

    ClearToBlack();
    return false;
}// Comp_In


///////////////////////////////////////////////////////////////////////////////
//
//      Composite this image "out" the given image.  See lecture notes for 
//  details.  Return success of operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::Comp_Out(TargaImage* pImage)
{
    if (width != pImage->width || height != pImage->height)
    {
        cout << "Comp_Out: Images not the same size\n";
        return false;
    }

    ClearToBlack();
    return false;
}// Comp_Out


///////////////////////////////////////////////////////////////////////////////
//
//      Composite current image "atop" given image.  Return success of 
//  operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::Comp_Atop(TargaImage* pImage)
{
    if (width != pImage->width || height != pImage->height)
    {
        cout << "Comp_Atop: Images not the same size\n";
        return false;
    }

    ClearToBlack();
    return false;
}// Comp_Atop


///////////////////////////////////////////////////////////////////////////////
//
//      Composite this image with given image using exclusive or (XOR).  Return
//  success of operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::Comp_Xor(TargaImage* pImage)
{
    if (width != pImage->width || height != pImage->height)
    {
        cout << "Comp_Xor: Images not the same size\n";
        return false;
    }

    ClearToBlack();
    return false;
}// Comp_Xor


///////////////////////////////////////////////////////////////////////////////
//
//      Calculate the difference bewteen this imag and the given one.  Image 
//  dimensions must be equal.  Return success of operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::Difference(TargaImage* pImage)
{
    if (!pImage)
        return false;

    if (width != pImage->width || height != pImage->height)
    {
        cout << "Difference: Images not the same size\n";
        return false;
    }// if

    for (int i = 0 ; i < width * height * 4 ; i += 4)
    {
        unsigned char        rgb1[3];
        unsigned char        rgb2[3];

        RGBA_To_RGB(data + i, rgb1);
        RGBA_To_RGB(pImage->data + i, rgb2);

        data[i] = abs(rgb1[0] - rgb2[0]);
        data[i+1] = abs(rgb1[1] - rgb2[1]);
        data[i+2] = abs(rgb1[2] - rgb2[2]);
        data[i+3] = 255;
    }

    return true;
}// Difference


///////////////////////////////////////////////////////////////////////////////
//
//      Perform 5x5 box filter on this image.  Return success of operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::Filter_Box()
{
    
    vector<double> numbers;
    unsigned char* newData;
    newData = new unsigned char[width * height * 4];

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            
            vector<double> colors;
            colors.push_back(0.0);
            colors.push_back(0.0);
            colors.push_back(0.0);

            for (int c = 0; c < 3; c++)
            {
                colors[c] += data[i * width * 4 + j * 4 + c] * 0.04;
                // up&down
                if (i >= 2 && i <= (height - 3))
                {
                    colors[c] += data[(i + 1) * width * 4 + j * 4 + c] * 0.04;
                    colors[c] += data[(i + 2) * width * 4 + j * 4 + c] * 0.04;
                    colors[c] += data[(i - 1) * width * 4 + j * 4 + c] * 0.04;
                    colors[c] += data[(i - 2) * width * 4 + j * 4 + c] * 0.04;
                }
                else if (i == 1 || i == height - 2)
                {
                    int direct = i == 1 ? 2 : -2;
                    colors[c] += data[(i + 1) * width * 4 + j * 4 + c] * 0.04;
                    colors[c] += data[(i + direct) * width * 4 + j * 4 + c] * 0.08;
                    colors[c] += data[(i - 1) * width * 4 + j * 4 + c] * 0.04;
                }
                else
                {
                    int direct = i == 0 ? 1 : -1;
                    colors[c] += data[(i + 1 * direct) * width * 4 + j * 4 + c] * 0.08;
                    colors[c] += data[(i + 2 * direct) * width * 4 + j * 4 + c] * 0.08;
                }
                
                if (j >= 2 && j <= (width - 3))
                {
                    colors[c] += data[i * width * 4 + (j + 1) * 4 + c] * 0.04;
                    colors[c] += data[i * width * 4 + (j + 2) * 4 + c] * 0.04;
                    colors[c] += data[i * width * 4 + (j - 1) * 4 + c] * 0.04;
                    colors[c] += data[i * width * 4 + (j - 2) * 4 + c] * 0.04;
                }
                else if (j == 1 || j == width - 2)
                {
                    int direct = j == 1 ? 2 : -2;
                    colors[c] += data[i * width * 4 + (j + 1) * 4 + c] * 0.04;
                    colors[c] += data[i * width * 4 + (j + direct) * 4 + c] * 0.08;
                    colors[c] += data[i * width * 4 + (j - 1) * 4 + c] * 0.04;
                }
                else
                {
                    int direct = j == 0 ? 1 : -1;
                    colors[c] += data[i * width * 4 + (j + 1 * direct) * 4 + c] * 0.08;
                    colors[c] += data[i * width * 4 + (j + 2 * direct) * 4 + c] * 0.08;
                }

                if (j >= 2 && j <= (width - 3) && i >= 2 && i <= (height - 3))
                {
                    // i + 1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1) * 4 + c] * 0.04;
                    colors[c] += data[(i + 1) * width * 4 + (j + 2) * 4 + c] * 0.04;
                    colors[c] += data[(i + 1) * width * 4 + (j - 1) * 4 + c] * 0.04;
                    colors[c] += data[(i + 1) * width * 4 + (j - 2) * 4 + c] * 0.04;
                    // i + 2
                    colors[c] += data[(i + 2) * width * 4 + (j + 1) * 4 + c] * 0.04;
                    colors[c] += data[(i + 2) * width * 4 + (j + 2) * 4 + c] * 0.04;
                    colors[c] += data[(i + 2) * width * 4 + (j - 1) * 4 + c] * 0.04;
                    colors[c] += data[(i + 2) * width * 4 + (j - 2) * 4 + c] * 0.04;
                    // i - 1
                    colors[c] += data[(i - 1) * width * 4 + (j + 1) * 4 + c] * 0.04;
                    colors[c] += data[(i - 1) * width * 4 + (j + 2) * 4 + c] * 0.04;
                    colors[c] += data[(i - 1) * width * 4 + (j - 1) * 4 + c] * 0.04;
                    colors[c] += data[(i - 1) * width * 4 + (j - 2) * 4 + c] * 0.04;
                    // i - 2
                    colors[c] += data[(i - 2) * width * 4 + (j + 1) * 4 + c] * 0.04;
                    colors[c] += data[(i - 2) * width * 4 + (j + 2) * 4 + c] * 0.04;
                    colors[c] += data[(i - 2) * width * 4 + (j - 1) * 4 + c] * 0.04;
                    colors[c] += data[(i - 2) * width * 4 + (j - 2) * 4 + c] * 0.04;
                }
                else if (i == 1 && j >= 2 && j <= (width - 3) || i == (height - 2) && j >= 2 && j <= (width - 3))
                {
                    int direct = i == 1 ? 2 : -2;
                    // i + 1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1) * 4 + c] * 0.04;
                    colors[c] += data[(i + 1) * width * 4 + (j + 2) * 4 + c] * 0.04;
                    colors[c] += data[(i + 1) * width * 4 + (j - 1) * 4 + c] * 0.04;
                    colors[c] += data[(i + 1) * width * 4 + (j - 2) * 4 + c] * 0.04;
                    // i + 2
                    colors[c] += data[(i + direct) * width * 4 + (j + 1) * 4 + c] * 0.08;
                    colors[c] += data[(i + direct) * width * 4 + (j + 2) * 4 + c] * 0.08;
                    colors[c] += data[(i + direct) * width * 4 + (j - 1) * 4 + c] * 0.08;
                    colors[c] += data[(i + direct) * width * 4 + (j - 2) * 4 + c] * 0.08;
                    // i - 1
                    colors[c] += data[(i - 1) * width * 4 + (j + 1) * 4 + c] * 0.04;
                    colors[c] += data[(i - 1) * width * 4 + (j + 2) * 4 + c] * 0.04;
                    colors[c] += data[(i - 1) * width * 4 + (j - 1) * 4 + c] * 0.04;
                    colors[c] += data[(i - 1) * width * 4 + (j - 2) * 4 + c] * 0.04;
                }
                else if (i == 0 && j >= 2 && j <= (width - 3) || i == (height - 1) && j >= 2 && j <= (width - 3))
                {
                    int direct = i == 0 ? 1 : -1;
                    // i + 1
                    colors[c] += data[(i + 1 * direct) * width * 4 + (j + 1) * 4 + c] * 0.08;
                    colors[c] += data[(i + 1 * direct) * width * 4 + (j + 2) * 4 + c] * 0.08;
                    colors[c] += data[(i + 1 * direct) * width * 4 + (j - 1) * 4 + c] * 0.08;
                    colors[c] += data[(i + 1 * direct) * width * 4 + (j - 2) * 4 + c] * 0.08;
                    // i + 2
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 1) * 4 + c] * 0.08;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 2) * 4 + c] * 0.08;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j - 1) * 4 + c] * 0.08;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j - 2) * 4 + c] * 0.08;
                }
                else if (j == 1 && i >= 2 && i <= (height - 3) || j == (width - 2) && i >= 2 && i <= (height - 3))
                {
                    int direct = j == 1 ? 2 : -2;
                    // i + 1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1) * 4 + c] * 0.04;
                    colors[c] += data[(i + 1) * width * 4 + (j + direct) * 4 + c] * 0.08;
                    colors[c] += data[(i + 1) * width * 4 + (j - 1) * 4 + c] * 0.04;

                    // i + 2
                    colors[c] += data[(i + 2) * width * 4 + (j + 1) * 4 + c] * 0.04;
                    colors[c] += data[(i + 2) * width * 4 + (j + direct) * 4 + c] * 0.08;
                    colors[c] += data[(i + 2) * width * 4 + (j - 1) * 4 + c] * 0.04;

                    // i - 1
                    colors[c] += data[(i - 1) * width * 4 + (j + 1) * 4 + c] * 0.04;
                    colors[c] += data[(i - 1) * width * 4 + (j + direct) * 4 + c] * 0.08;
                    colors[c] += data[(i - 1) * width * 4 + (j - 1) * 4 + c] * 0.04;

                    // i - 2
                    colors[c] += data[(i - 2) * width * 4 + (j + 1) * 4 + c] * 0.04;
                    colors[c] += data[(i - 2) * width * 4 + (j + direct) * 4 + c] * 0.08;
                    colors[c] += data[(i - 2) * width * 4 + (j - 1) * 4 + c] * 0.04;

                }
                else if (j == 0 && i >= 2 && i <= (height - 3) || j == (width - 1) && i >= 2 && i <= (height - 3))
                {
                    int direct = j == 0 ? 1 : -1;
                    // i + 1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1 * direct) * 4 + c] * 0.08;
                    colors[c] += data[(i + 1) * width * 4 + (j + 2 * direct) * 4 + c] * 0.08;

                    // i + 2
                    colors[c] += data[(i + 2) * width * 4 + (j + 1 * direct) * 4 + c] * 0.08;
                    colors[c] += data[(i + 2) * width * 4 + (j + 2 * direct) * 4 + c] * 0.08;

                    // i - 1
                    colors[c] += data[(i - 1) * width * 4 + (j + 1 * direct) * 4 + c] * 0.08;
                    colors[c] += data[(i - 1) * width * 4 + (j + 2 * direct) * 4 + c] * 0.08;

                    // i - 2
                    colors[c] += data[(i - 2) * width * 4 + (j + 1 * direct) * 4 + c] * 0.08;
                    colors[c] += data[(i - 2) * width * 4 + (j + 2 * direct) * 4 + c] * 0.08;
                }
                else if (j == 1 && i == 1 || j == width - 2 && i == height - 2)
                {
                    int direct = j == 1 ? 2 : -2;
                    // +1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1) * 4 + c] * 0.04;   
                    colors[c] += data[(i + 1) * width * 4 + (j - 1) * 4 + c] * 0.04;
                    colors[c] += data[(i - 1) * width * 4 + (j + 1) * 4 + c] * 0.04;
                    colors[c] += data[(i - 1) * width * 4 + (j - 1) * 4 + c] * 0.04;
                    // i - 2
                    colors[c] += data[(i + direct) * width * 4 + (j + 1) * 4 + c] * 0.08;
                    colors[c] += data[(i + direct) * width * 4 + (j - 1) * 4 + c] * 0.08;
                    colors[c] += data[(i + 1) * width * 4 + (j + direct) * 4 + c] * 0.08;
                    colors[c] += data[(i - 1) * width * 4 + (j + direct) * 4 + c] * 0.08;
                    // i + 2
                    colors[c] += data[(i + direct) * width * 4 + (j + direct) * 4 + c] * 0.16;
                }
                else if (j == 1 && i == height - 2 || j == width - 2 && i == 1)
                {
                    int direct = j == 1 ? 2 : -2;
                    // +1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1) * 4 + c] * 0.04;
                    colors[c] += data[(i + 1) * width * 4 + (j - 1) * 4 + c] * 0.04;
                    colors[c] += data[(i - 1) * width * 4 + (j + 1) * 4 + c] * 0.04;
                    colors[c] += data[(i - 1) * width * 4 + (j - 1) * 4 + c] * 0.04;
                    // i - 2
                    colors[c] += data[(i - direct) * width * 4 + (j + 1) * 4 + c] * 0.08;
                    colors[c] += data[(i - direct) * width * 4 + (j - 1) * 4 + c] * 0.08;
                    colors[c] += data[(i + 1) * width * 4 + (j + direct) * 4 + c] * 0.08;
                    colors[c] += data[(i - 1) * width * 4 + (j + direct) * 4 + c] * 0.08;
                    // i + 2
                    colors[c] += data[(i - direct) * width * 4 + (j + direct) * 4 + c] * 0.16;
                }
                else if (j == 0 && i == 0 || j == width - 1 && i == height - 1)
                {
                    int direct = j == 0 ? 1 : -1;
 
                    colors[c] += data[(i + 1 * direct) * width * 4 + (j + 1 * direct) * 4 + c] * 0.16;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 1 * direct) * 4 + c] * 0.16;
                    colors[c] += data[(i + 1 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 0.16;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 0.16;
                }
                else if (j == 0 && i == height - 1 || i == 0 && j == width - 1)
                {
                    int direct = j == 0 ? 1 : -1;

                    colors[c] += data[(i - 1 * direct) * width * 4 + (j + 1 * direct) * 4 + c] * 0.16;
                    colors[c] += data[(i - 2 * direct) * width * 4 + (j + 1 * direct) * 4 + c] * 0.16;
                    colors[c] += data[(i - 1 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 0.16;
                    colors[c] += data[(i - 2 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 0.16;
                }
                else if (j == 1 && i == 0 || j == width - 2 && i == height - 1)
                {
                    int direct = i == 0 ? 1 : -1;
                    // i + 1
                    colors[c] += data[(i + 1 * direct) * width * 4 + (j + 1) * 4 + c] * 0.08;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 1) * 4 + c] * 0.08;
                    colors[c] += data[(i + 1 * direct) * width * 4 + (j - 1) * 4 + c] * 0.08;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j - 1) * 4 + c] * 0.08;

                    colors[c] += data[(i + 1 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 0.16;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 0.16;

                }
                else if (j == 1 && i == height - 1 || j == width - 2 && i == 0)
                {
                    int direct = j == 1 ? 1 : -1;
                    // i + 1
                    colors[c] += data[(i - 1 * direct) * width * 4 + (j + 1) * 4 + c] * 0.08;
                    colors[c] += data[(i - 2 * direct) * width * 4 + (j + 1) * 4 + c] * 0.08;
                    colors[c] += data[(i - 1 * direct) * width * 4 + (j - 1) * 4 + c] * 0.08;
                    colors[c] += data[(i - 2 * direct) * width * 4 + (j - 1) * 4 + c] * 0.08;

                    colors[c] += data[(i - 1 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 0.16;
                    colors[c] += data[(i - 2 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 0.16;

                }
                else if (j == 0 && i == 1 || j == width - 1 && i == height - 2)
                {   
                    int direct = j == 0 ? 1 : -1;
                    // i + 1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1 * direct) * 4 + c] * 0.08;
                    colors[c] += data[(i + 1) * width * 4 + (j + 2 * direct) * 4 + c] * 0.08;
                    colors[c] += data[(i - 1) * width * 4 + (j + 1 * direct) * 4 + c] * 0.08;
                    colors[c] += data[(i - 1) * width * 4 + (j + 2 * direct) * 4 + c] * 0.08;

                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 1 * direct) * 4 + c] * 0.16;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 0.16;
                }
                else if(j == 0 && i == height - 2 || j == width - 1 && i == 1)
                {
                    int direct = i == 1 ? -1 : 1;
                    // i + 1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1 * direct) * 4 + c] * 0.08;
                    colors[c] += data[(i + 1) * width * 4 + (j + 2 * direct) * 4 + c] * 0.08;
                    colors[c] += data[(i - 1) * width * 4 + (j + 1 * direct) * 4 + c] * 0.08;
                    colors[c] += data[(i - 1) * width * 4 + (j + 2 * direct) * 4 + c] * 0.08;

                    colors[c] += data[(i - 2 * direct) * width * 4 + (j + 1 * direct) * 4 + c] * 0.16;
                    colors[c] += data[(i - 2 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 0.16;
                }
                else
                {
                    cout << "wrong" << endl;
                }
                
            }

            newData[i * width * 4 + j * 4] = colors[0];
            newData[i * width * 4 + j * 4 + 1] = colors[1];
            newData[i * width * 4 + j * 4 + 2] = colors[2];
        }
    }




    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            data[i * width * 4 + j * 4] = newData[i * width * 4 + j * 4];
            data[i * width * 4 + j * 4 + 1] = newData[i * width * 4 + j * 4 + 1];
            data[i * width * 4 + j * 4 + 2] = newData[i * width * 4 + j * 4 + 2];
        }
    }


    return true;
}// Filter_Box


///////////////////////////////////////////////////////////////////////////////
//
//      Perform 5x5 Bartlett filter on this image.  Return success of 
//  operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::Filter_Bartlett()
{
    
    unsigned char* newData;
    newData = new unsigned char[width * height * 4];
    double six = 6.0 / 81.0;
    double three = 3.0 / 81.0;



    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {

            vector<double> colors;
            colors.push_back(0.0);
            colors.push_back(0.0);
            colors.push_back(0.0);

            for (int c = 0; c < 3; c++)
            {
                colors[c] += data[i * width * 4 + j * 4 + c] * 9 / 81;
                // up&down
                if (i >= 2 && i <= (height - 3))
                {
                    colors[c] += data[(i + 1) * width * 4 + j * 4 + c] * 6.0 / 81.0;
                    colors[c] += data[(i + 2) * width * 4 + j * 4 + c] * 3.0 / 81.0;
                    colors[c] += data[(i - 1) * width * 4 + j * 4 + c] * 6.0 / 81.0;
                    colors[c] += data[(i - 2) * width * 4 + j * 4 + c] * 3.0 / 81.0;
                }
                else if (i == 1 || i == height - 2)
                {
                    int direct = i == 1 ? 2 : -2;
                    colors[c] += data[(i + 1) * width * 4 + j * 4 + c] * 6.0 / 81.0;
                    colors[c] += data[(i + direct) * width * 4 + j * 4 + c] * 6.0 / 81.0;
                    colors[c] += data[(i - 1) * width * 4 + j * 4 + c] * 6.0 / 81.0;
                }
                else
                {
                    int direct = i == 0 ? 1 : -1;
                    colors[c] += data[(i + 1 * direct) * width * 4 + j * 4 + c] * 12.0 / 81.0;
                    colors[c] += data[(i + 2 * direct) * width * 4 + j * 4 + c] * 6.0 / 81.0;
                }

                if (j >= 2 && j <= (width - 3))
                {
                    colors[c] += data[i * width * 4 + (j + 1) * 4 + c] * 6.0 / 81;
                    colors[c] += data[i * width * 4 + (j + 2) * 4 + c] * 3.0 / 81;
                    colors[c] += data[i * width * 4 + (j - 1) * 4 + c] * 6.0 / 81;
                    colors[c] += data[i * width * 4 + (j - 2) * 4 + c] * 3.0 / 81;
                }
                else if (j == 1 || j == width - 2)
                {
                    int direct = j == 1 ? 2 : -2;
                    colors[c] += data[i * width * 4 + (j + 1) * 4 + c] * 6.0 / 81;
                    colors[c] += data[i * width * 4 + (j + direct) * 4 + c] * 6.0 / 81;
                    colors[c] += data[i * width * 4 + (j - 1) * 4 + c] * 6.0 / 81;
                }
                else
                {
                    int direct = j == 0 ? 1 : -1;
                    colors[c] += data[i * width * 4 + (j + 1 * direct) * 4 + c] * 12.0 / 81;
                    colors[c] += data[i * width * 4 + (j + 2 * direct) * 4 + c] * 6.0 / 81;
                }

                if (j >= 2 && j <= (width - 3) && i >= 2 && i <= (height - 3))
                {
                    // i + 1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i + 1) * width * 4 + (j + 2) * 4 + c] * 2.0 / 81;
                    colors[c] += data[(i + 1) * width * 4 + (j - 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i + 1) * width * 4 + (j - 2) * 4 + c] * 2.0 / 81;
                    // i + 2
                    colors[c] += data[(i + 2) * width * 4 + (j + 1) * 4 + c] * 2.0 / 81;
                    colors[c] += data[(i + 2) * width * 4 + (j + 2) * 4 + c] * 1.0 / 81;
                    colors[c] += data[(i + 2) * width * 4 + (j - 1) * 4 + c] * 2.0 / 81;
                    colors[c] += data[(i + 2) * width * 4 + (j - 2) * 4 + c] * 1.0 / 81;
                    // i - 1
                    colors[c] += data[(i - 1) * width * 4 + (j + 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i - 1) * width * 4 + (j + 2) * 4 + c] * 2.0 / 81;
                    colors[c] += data[(i - 1) * width * 4 + (j - 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i - 1) * width * 4 + (j - 2) * 4 + c] * 2.0 / 81;
                    // i - 2
                    colors[c] += data[(i - 2) * width * 4 + (j + 1) * 4 + c] * 2.0 / 81;
                    colors[c] += data[(i - 2) * width * 4 + (j + 2) * 4 + c] * 1.0 / 81;
                    colors[c] += data[(i - 2) * width * 4 + (j - 1) * 4 + c] * 2.0 / 81;
                    colors[c] += data[(i - 2) * width * 4 + (j - 2) * 4 + c] * 1.0 / 81;
                }
                else if (i == 1 && j >= 2 && j <= (width - 3) || i == (height - 2) && j >= 2 && j <= (width - 3))
                {
                    int direct = i == 1 ? 2 : -2;
                    // i + 1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i + 1) * width * 4 + (j + 2) * 4 + c] * 2.0 / 81;
                    colors[c] += data[(i + 1) * width * 4 + (j - 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i + 1) * width * 4 + (j - 2) * 4 + c] * 2.0 / 81;
                    // i + 2
                    colors[c] += data[(i + direct) * width * 4 + (j + 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i + direct) * width * 4 + (j + 2) * 4 + c] * 2.0 / 81;
                    colors[c] += data[(i + direct) * width * 4 + (j - 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i + direct) * width * 4 + (j - 2) * 4 + c] * 2.0 / 81;
                    // i - 1
                    colors[c] += data[(i - 1) * width * 4 + (j + 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i - 1) * width * 4 + (j + 2) * 4 + c] * 2.0 / 81;
                    colors[c] += data[(i - 1) * width * 4 + (j - 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i - 1) * width * 4 + (j - 2) * 4 + c] * 2.0 / 81;
                }
                else if (i == 0 && j >= 2 && j <= (width - 3) || i == (height - 1) && j >= 2 && j <= (width - 3))
                {
                    int direct = i == 0 ? 1 : -1;
                    // i + 1
                    colors[c] += data[(i + 1 * direct) * width * 4 + (j + 1) * 4 + c] * 8.0 / 81;
                    colors[c] += data[(i + 1 * direct) * width * 4 + (j + 2) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i + 1 * direct) * width * 4 + (j - 1) * 4 + c] * 8.0 / 81;
                    colors[c] += data[(i + 1 * direct) * width * 4 + (j - 2) * 4 + c] * 4.0 / 81;
                    // i + 2
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 2) * 4 + c] * 2.0 / 81;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j - 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j - 2) * 4 + c] * 2.0 / 81;
                }
                else if (j == 1 && i >= 2 && i <= (height - 3) || j == (width - 2) && i >= 2 && i <= (height - 3))
                {
                    int direct = j == 1 ? 2 : -2;
                    // i + 1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i + 1) * width * 4 + (j + direct) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i + 1) * width * 4 + (j - 1) * 4 + c] * 4.0 / 81;

                    // i + 2
                    colors[c] += data[(i + 2) * width * 4 + (j + 1) * 4 + c] * 2.0 / 81;
                    colors[c] += data[(i + 2) * width * 4 + (j + direct) * 4 + c] * 2.0 / 81;
                    colors[c] += data[(i + 2) * width * 4 + (j - 1) * 4 + c] * 2.0 / 81;

                    // i - 1
                    colors[c] += data[(i - 1) * width * 4 + (j + 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i - 1) * width * 4 + (j + direct) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i - 1) * width * 4 + (j - 1) * 4 + c] * 4.0 / 81;

                    // i - 2
                    colors[c] += data[(i - 2) * width * 4 + (j + 1) * 4 + c] * 2.0 / 81;
                    colors[c] += data[(i - 2) * width * 4 + (j + direct) * 4 + c] * 2.0 / 81;
                    colors[c] += data[(i - 2) * width * 4 + (j - 1) * 4 + c] * 2.0 / 81;

                }
                else if (j == 0 && i >= 2 && i <= (height - 3) || j == (width - 1) && i >= 2 && i <= (height - 3))
                {
                    int direct = j == 0 ? 1 : -1;
                    // i + 1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1 * direct) * 4 + c] * 8.0 / 81;
                    colors[c] += data[(i + 1) * width * 4 + (j + 2 * direct) * 4 + c] * 4.0 / 81;

                    // i + 2
                    colors[c] += data[(i + 2) * width * 4 + (j + 1 * direct) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i + 2) * width * 4 + (j + 2 * direct) * 4 + c] * 2.0 / 81;

                    // i - 1
                    colors[c] += data[(i - 1) * width * 4 + (j + 1 * direct) * 4 + c] * 8.0 / 81;
                    colors[c] += data[(i - 1) * width * 4 + (j + 2 * direct) * 4 + c] * 4.0 / 81;

                    // i - 2
                    colors[c] += data[(i - 2) * width * 4 + (j + 1 * direct) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i - 2) * width * 4 + (j + 2 * direct) * 4 + c] * 2.0 / 81;
                }
                else if (j == 1 && i == 1 || j == width - 2 && i == height - 2)
                {
                    int direct = j == 1 ? 2 : -2;
                    // +1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i + 1) * width * 4 + (j - 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i - 1) * width * 4 + (j + 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i - 1) * width * 4 + (j - 1) * 4 + c] * 4.0 / 81;
                    // i - 2
                    colors[c] += data[(i + direct) * width * 4 + (j + 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i + direct) * width * 4 + (j - 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i + 1) * width * 4 + (j + direct) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i - 1) * width * 4 + (j + direct) * 4 + c] * 4.0 / 81;
                    // i + 2
                    colors[c] += data[(i + direct) * width * 4 + (j + direct) * 4 + c] * 4 / 81;
                }
                else if (j == 1 && i == height - 2 || j == width - 2 && i == 1)
                {
                    int direct = j == 1 ? 2 : -2;
                    // +1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i + 1) * width * 4 + (j - 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i - 1) * width * 4 + (j + 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i - 1) * width * 4 + (j - 1) * 4 + c] * 4.0 / 81;
                    // i - 2
                    colors[c] += data[(i - direct) * width * 4 + (j + 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i - direct) * width * 4 + (j - 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i + 1) * width * 4 + (j + direct) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i - 1) * width * 4 + (j + direct) * 4 + c] * 4.0 / 81;
                    // i + 2
                    colors[c] += data[(i - direct) * width * 4 + (j + direct) * 4 + c] * 4 / 81;
                }
                else if (j == 0 && i == 0 || j == width - 1 && i == height - 1)
                {
                    int direct = j == 0 ? 1 : -1;

                    colors[c] += data[(i + 1 * direct) * width * 4 + (j + 1 * direct) * 4 + c] * 16.0 / 81;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 1 * direct) * 4 + c] * 8.0 / 81;
                    colors[c] += data[(i + 1 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 8.0 / 81;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 4.0 / 81;
                }
                else if (j == 0 && i == height - 1 || i == 0 && j == width - 1)
                {
                    int direct = j == 0 ? 1 : -1;

                    colors[c] += data[(i - 1 * direct) * width * 4 + (j + 1 * direct) * 4 + c] * 16.0 / 81;
                    colors[c] += data[(i - 2 * direct) * width * 4 + (j + 1 * direct) * 4 + c] * 8.0 / 81;
                    colors[c] += data[(i - 1 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 8.0 / 81;
                    colors[c] += data[(i - 2 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 4.0 / 81;
                }
                else if (j == 1 && i == 0 || j == width - 2 && i == height - 1)
                {
                    int direct = i == 0 ? 1 : -1;
                    // i + 1
                    colors[c] += data[(i + 1 * direct) * width * 4 + (j + 1) * 4 + c] * 8.0 / 81;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i + 1 * direct) * width * 4 + (j - 1) * 4 + c] * 8.0 / 81;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j - 1) * 4 + c] * 4.0 / 81;

                    colors[c] += data[(i + 1 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 8.0 / 81;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 4.0 / 81;

                }
                else if (j == 1 && i == height - 1 || j == width - 2 && i == 0)
                {
                    int direct = j == 1 ? 1 : -1;
                    // i + 1
                    colors[c] += data[(i - 1 * direct) * width * 4 + (j + 1) * 4 + c] * 8.0 / 81;
                    colors[c] += data[(i - 2 * direct) * width * 4 + (j + 1) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i - 1 * direct) * width * 4 + (j - 1) * 4 + c] * 8.0 / 81;
                    colors[c] += data[(i - 2 * direct) * width * 4 + (j - 1) * 4 + c] * 4.0 / 81;

                    colors[c] += data[(i - 1 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 8.0 / 81;
                    colors[c] += data[(i - 2 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 4.0 / 81;

                }
                else if (j == 0 && i == 1 || j == width - 1 && i == height - 2)
                {
                    int direct = j == 0 ? 1 : -1;
                    // i + 1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1 * direct) * 4 + c] * 8.0 / 81;
                    colors[c] += data[(i + 1) * width * 4 + (j + 2 * direct) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i - 1) * width * 4 + (j + 1 * direct) * 4 + c] * 8.0 / 81;
                    colors[c] += data[(i - 1) * width * 4 + (j + 2 * direct) * 4 + c] * 4.0 / 81;

                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 1 * direct) * 4 + c] * 8.0 / 81;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 4.0 / 81;
                }
                else if (j == 0 && i == height - 2 || j == width - 1 && i == 1)
                {
                    int direct = i == 1 ? -1 : 1;
                    // i + 1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1 * direct) * 4 + c] * 8.0 / 81;
                    colors[c] += data[(i + 1) * width * 4 + (j + 2 * direct) * 4 + c] * 4.0 / 81;
                    colors[c] += data[(i - 1) * width * 4 + (j + 1 * direct) * 4 + c] * 8.0 / 81;
                    colors[c] += data[(i - 1) * width * 4 + (j + 2 * direct) * 4 + c] * 4.0 / 81;

                    colors[c] += data[(i - 2 * direct) * width * 4 + (j + 1 * direct) * 4 + c] * 8.0 / 81;
                    colors[c] += data[(i - 2 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 4.0 / 81;
                }
                else
                {
                    cout << "wrong" << endl;
                }

            }

            newData[i * width * 4 + j * 4] = colors[0];
            newData[i * width * 4 + j * 4 + 1] = colors[1];
            newData[i * width * 4 + j * 4 + 2] = colors[2];
        }
    }

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            data[i * width * 4 + j * 4] = newData[i * width * 4 + j * 4];
            data[i * width * 4 + j * 4 + 1] = newData[i * width * 4 + j * 4 + 1];
            data[i * width * 4 + j * 4 + 2] = newData[i * width * 4 + j * 4 + 2];
        }
    }




    return true;
}// Filter_Bartlett


///////////////////////////////////////////////////////////////////////////////
//
//      Perform 5x5 Gaussian filter on this image.  Return success of 
//  operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::Filter_Gaussian()
{
    
    unsigned char* newData;
    newData = new unsigned char[width * height * 4];

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {

            vector<double> colors;
            colors.push_back(0.0);
            colors.push_back(0.0);
            colors.push_back(0.0);

            for (int c = 0; c < 3; c++)
            {
                colors[c] += data[i * width * 4 + j * 4 + c] * 36.0 / 256.0;
                // up&down
                if (i >= 2 && i <= (height - 3))
                {
                    colors[c] += data[(i + 1) * width * 4 + j * 4 + c] * 24.0 / 256.0;
                    colors[c] += data[(i + 2) * width * 4 + j * 4 + c] * 6.0 / 256.0;
                    colors[c] += data[(i - 1) * width * 4 + j * 4 + c] * 24.0 / 256.0;
                    colors[c] += data[(i - 2) * width * 4 + j * 4 + c] * 6.0 / 256.0;
                }
                else if (i == 1 || i == height - 2)
                {
                    int direct = i == 1 ? 2 : -2;
                    colors[c] += data[(i + 1) * width * 4 + j * 4 + c] * 24.0 / 256.0;
                    colors[c] += data[(i + direct) * width * 4 + j * 4 + c] * 12.0 / 256.0;
                    colors[c] += data[(i - 1) * width * 4 + j * 4 + c] * 24.0 / 256.0;
                }
                else
                {
                    int direct = i == 0 ? 1 : -1;
                    colors[c] += data[(i + 1 * direct) * width * 4 + j * 4 + c] * 48.0 / 256.0;
                    colors[c] += data[(i + 2 * direct) * width * 4 + j * 4 + c] * 12.0 / 256.0;
                }

                if (j >= 2 && j <= (width - 3))
                {
                    colors[c] += data[i * width * 4 + (j + 1) * 4 + c] * 24.0 / 256.0;
                    colors[c] += data[i * width * 4 + (j + 2) * 4 + c] * 6.0 / 256.0;
                    colors[c] += data[i * width * 4 + (j - 1) * 4 + c] * 24.0 / 256.0;
                    colors[c] += data[i * width * 4 + (j - 2) * 4 + c] * 6.0 / 256.0;
                }
                else if (j == 1 || j == width - 2)
                {
                    int direct = j == 1 ? 2 : -2;
                    colors[c] += data[i * width * 4 + (j + 1) * 4 + c] * 24.0 / 256.0;
                    colors[c] += data[i * width * 4 + (j + direct) * 4 + c] * 12.0 / 256.0;
                    colors[c] += data[i * width * 4 + (j - 1) * 4 + c] * 24.0 / 256.0;
                }
                else
                {
                    int direct = j == 0 ? 1 : -1;
                    colors[c] += data[i * width * 4 + (j + 1 * direct) * 4 + c] * 48.0 / 256.0;
                    colors[c] += data[i * width * 4 + (j + 2 * direct) * 4 + c] * 12.0 / 256.0;
                }

                if (j >= 2 && j <= (width - 3) && i >= 2 && i <= (height - 3))
                {
                    // i + 1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i + 1) * width * 4 + (j + 2) * 4 + c] * 4.0 / 256.0;
                    colors[c] += data[(i + 1) * width * 4 + (j - 1) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i + 1) * width * 4 + (j - 2) * 4 + c] * 4.0 / 256.0;
                    // i + 2
                    colors[c] += data[(i + 2) * width * 4 + (j + 1) * 4 + c] * 4.0 / 256.0;
                    colors[c] += data[(i + 2) * width * 4 + (j + 2) * 4 + c] * 1.0 / 256.0;
                    colors[c] += data[(i + 2) * width * 4 + (j - 1) * 4 + c] * 4.0 / 256.0;
                    colors[c] += data[(i + 2) * width * 4 + (j - 2) * 4 + c] * 1.0 / 256.0;
                    // i - 1
                    colors[c] += data[(i - 1) * width * 4 + (j + 1) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i - 1) * width * 4 + (j + 2) * 4 + c] * 4.0 / 256.0;
                    colors[c] += data[(i - 1) * width * 4 + (j - 1) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i - 1) * width * 4 + (j - 2) * 4 + c] * 4.0 / 256.0;
                    // i - 2
                    colors[c] += data[(i - 2) * width * 4 + (j + 1) * 4 + c] * 4.0 / 256.0;
                    colors[c] += data[(i - 2) * width * 4 + (j + 2) * 4 + c] * 1.0 / 256.0;
                    colors[c] += data[(i - 2) * width * 4 + (j - 1) * 4 + c] * 4.0 / 256.0;
                    colors[c] += data[(i - 2) * width * 4 + (j - 2) * 4 + c] * 1.0 / 256.0;
                }
                else if (i == 1 && j >= 2 && j <= (width - 3) || i == (height - 2) && j >= 2 && j <= (width - 3))
                {
                    int direct = i == 1 ? 2 : -2;
                    // i + 1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i + 1) * width * 4 + (j + 2) * 4 + c] * 4.0 / 256.0;
                    colors[c] += data[(i + 1) * width * 4 + (j - 1) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i + 1) * width * 4 + (j - 2) * 4 + c] * 4.0 / 256.0;
                    // i + 2
                    colors[c] += data[(i + direct) * width * 4 + (j + 1) * 4 + c] * 8.0 / 256.0;
                    colors[c] += data[(i + direct) * width * 4 + (j + 2) * 4 + c] * 2.0 / 256.0;
                    colors[c] += data[(i + direct) * width * 4 + (j - 1) * 4 + c] * 8.0 / 256.0;
                    colors[c] += data[(i + direct) * width * 4 + (j - 2) * 4 + c] * 2.0 / 256.0;
                    // i - 1
                    colors[c] += data[(i - 1) * width * 4 + (j + 1) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i - 1) * width * 4 + (j + 2) * 4 + c] * 4.0 / 256.0;
                    colors[c] += data[(i - 1) * width * 4 + (j - 1) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i - 1) * width * 4 + (j - 2) * 4 + c] * 4.0 / 256.0;
                }
                else if (i == 0 && j >= 2 && j <= (width - 3) || i == (height - 1) && j >= 2 && j <= (width - 3))
                {
                    int direct = i == 0 ? 1 : -1;
                    // i + 1
                    colors[c] += data[(i + 1 * direct) * width * 4 + (j + 1) * 4 + c] * 32.0 / 256.0;
                    colors[c] += data[(i + 1 * direct) * width * 4 + (j + 2) * 4 + c] * 8.0 / 256.0;
                    colors[c] += data[(i + 1 * direct) * width * 4 + (j - 1) * 4 + c] * 32.0 / 256.0;
                    colors[c] += data[(i + 1 * direct) * width * 4 + (j - 2) * 4 + c] * 8.0 / 256.0;
                    // i + 2
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 1) * 4 + c] * 8.0 / 256.0;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 2) * 4 + c] * 2.0 / 256.0;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j - 1) * 4 + c] * 8.0 / 256.0;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j - 2) * 4 + c] * 2.0 / 256.0;
                }
                else if (j == 1 && i >= 2 && i <= (height - 3) || j == (width - 2) && i >= 2 && i <= (height - 3))
                {
                    int direct = j == 1 ? 2 : -2;
                    // i + 1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i + 1) * width * 4 + (j + direct) * 4 + c] * 8.0 / 256.0;
                    colors[c] += data[(i + 1) * width * 4 + (j - 1) * 4 + c] * 16.0 / 256.0;

                    // i + 2
                    colors[c] += data[(i + 2) * width * 4 + (j + 1) * 4 + c] * 4.0 / 256.0;
                    colors[c] += data[(i + 2) * width * 4 + (j + direct) * 4 + c] * 2.0 / 256.0;
                    colors[c] += data[(i + 2) * width * 4 + (j - 1) * 4 + c] * 4.0 / 256.0;

                    // i - 1
                    colors[c] += data[(i - 1) * width * 4 + (j + 1) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i - 1) * width * 4 + (j + direct) * 4 + c] * 8.0 / 256.0;
                    colors[c] += data[(i - 1) * width * 4 + (j - 1) * 4 + c] * 16.0 / 256.0;

                    // i - 2
                    colors[c] += data[(i - 2) * width * 4 + (j + 1) * 4 + c] * 4.0 / 256.0;
                    colors[c] += data[(i - 2) * width * 4 + (j + direct) * 4 + c] * 2.0 / 256.0;
                    colors[c] += data[(i - 2) * width * 4 + (j - 1) * 4 + c] * 4.0 / 256.0;

                }
                else if (j == 0 && i >= 2 && i <= (height - 3) || j == (width - 1) && i >= 2 && i <= (height - 3))
                {
                    int direct = j == 0 ? 1 : -1;
                    // i + 1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1 * direct) * 4 + c] * 32.0 / 256.0;
                    colors[c] += data[(i + 1) * width * 4 + (j + 2 * direct) * 4 + c] * 8.0 / 256.0;

                    // i + 2
                    colors[c] += data[(i + 2) * width * 4 + (j + 1 * direct) * 4 + c] * 8.0 / 256.0;
                    colors[c] += data[(i + 2) * width * 4 + (j + 2 * direct) * 4 + c] * 2.0 / 256.0;

                    // i - 1
                    colors[c] += data[(i - 1) * width * 4 + (j + 1 * direct) * 4 + c] * 32.0 / 256.0;
                    colors[c] += data[(i - 1) * width * 4 + (j + 2 * direct) * 4 + c] * 8.0 / 256.0;

                    // i - 2
                    colors[c] += data[(i - 2) * width * 4 + (j + 1 * direct) * 4 + c] * 8.0 / 256.0;
                    colors[c] += data[(i - 2) * width * 4 + (j + 2 * direct) * 4 + c] * 2.0 / 256.0;
                }
                else if (j == 1 && i == 1 || j == width - 2 && i == height - 2)
                {
                    int direct = j == 1 ? 2 : -2;
                    // +1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i + 1) * width * 4 + (j - 1) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i - 1) * width * 4 + (j + 1) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i - 1) * width * 4 + (j - 1) * 4 + c] * 16.0 / 256.0;
                    // i - 2
                    colors[c] += data[(i + direct) * width * 4 + (j + 1) * 4 + c] * 8.0 / 256.0;
                    colors[c] += data[(i + direct) * width * 4 + (j - 1) * 4 + c] * 8.0 / 256.0;
                    colors[c] += data[(i + 1) * width * 4 + (j + direct) * 4 + c] * 8.0 / 256.0;
                    colors[c] += data[(i - 1) * width * 4 + (j + direct) * 4 + c] * 8.0 / 256.0;
                    // i + 2
                    colors[c] += data[(i + direct) * width * 4 + (j + direct) * 4 + c] * 4.0 / 256.0;
                }
                else if (j == 1 && i == height - 2 || j == width - 2 && i == 1)
                {
                    int direct = j == 1 ? 2 : -2;
                    // +1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i + 1) * width * 4 + (j - 1) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i - 1) * width * 4 + (j + 1) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i - 1) * width * 4 + (j - 1) * 4 + c] * 16.0 / 256.0;
                    // i - 2
                    colors[c] += data[(i - direct) * width * 4 + (j + 1) * 4 + c] * 8.0 / 256.0;
                    colors[c] += data[(i - direct) * width * 4 + (j - 1) * 4 + c] * 8.0 / 256.0;
                    colors[c] += data[(i + 1) * width * 4 + (j + direct) * 4 + c] * 8.0 / 256.0;
                    colors[c] += data[(i - 1) * width * 4 + (j + direct) * 4 + c] * 8.0 / 256.0;
                    // i + 2
                    colors[c] += data[(i - direct) * width * 4 + (j + direct) * 4 + c] * 4.0 / 256.0;
                }
                else if (j == 0 && i == 0 || j == width - 1 && i == height - 1)
                {
                    int direct = j == 0 ? 1 : -1;

                    colors[c] += data[(i + 1 * direct) * width * 4 + (j + 1 * direct) * 4 + c] * 64.0 / 256.0;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 1 * direct) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i + 1 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 4.0 / 256.0;
                }
                else if (j == 0 && i == height - 1 || i == 0 && j == width - 1)
                {
                    int direct = j == 0 ? 1 : -1;

                    colors[c] += data[(i - 1 * direct) * width * 4 + (j + 1 * direct) * 4 + c] * 64.0 / 256.0;
                    colors[c] += data[(i - 2 * direct) * width * 4 + (j + 1 * direct) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i - 1 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i - 2 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 4.0 / 256.0;
                }
                else if (j == 1 && i == 0 || j == width - 2 && i == height - 1)
                {
                    int direct = i == 0 ? 1 : -1;
                    // i + 1
                    colors[c] += data[(i + 1 * direct) * width * 4 + (j + 1) * 4 + c] * 32.0 / 256.0;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 1) * 4 + c] * 8.0 / 256.0;
                    colors[c] += data[(i + 1 * direct) * width * 4 + (j - 1) * 4 + c] * 32.0 / 256.0;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j - 1) * 4 + c] * 8.0 / 256.0;

                    colors[c] += data[(i + 1 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 4.0 / 256.0;

                }
                else if (j == 1 && i == height - 1 || j == width - 2 && i == 0)
                {
                    int direct = j == 1 ? 1 : -1;
                    // i + 1
                    colors[c] += data[(i - 1 * direct) * width * 4 + (j + 1) * 4 + c] * 32.0 / 256.0;
                    colors[c] += data[(i - 2 * direct) * width * 4 + (j + 1) * 4 + c] * 8.0 / 256.0;
                    colors[c] += data[(i - 1 * direct) * width * 4 + (j - 1) * 4 + c] * 32.0 / 256.0;
                    colors[c] += data[(i - 2 * direct) * width * 4 + (j - 1) * 4 + c] * 8.0 / 256.0;

                    colors[c] += data[(i - 1 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i - 2 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 4.0 / 256.0;

                }
                else if (j == 0 && i == 1 || j == width - 1 && i == height - 2)
                {
                    int direct = j == 0 ? 1 : -1;
                    // i + 1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1 * direct) * 4 + c] * 32.0 / 256.0;
                    colors[c] += data[(i + 1) * width * 4 + (j + 2 * direct) * 4 + c] * 8.0 / 256.0;
                    colors[c] += data[(i - 1) * width * 4 + (j + 1 * direct) * 4 + c] * 32.0 / 256.0;
                    colors[c] += data[(i - 1) * width * 4 + (j + 2 * direct) * 4 + c] * 8.0 / 256.0;

                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 1 * direct) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i + 2 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 4.0 / 256.0;
                }
                else if (j == 0 && i == height - 2 || j == width - 1 && i == 1)
                {
                    int direct = i == 1 ? -1 : 1;
                    // i + 1
                    colors[c] += data[(i + 1) * width * 4 + (j + 1 * direct) * 4 + c] * 32.0 / 256.0;
                    colors[c] += data[(i + 1) * width * 4 + (j + 2 * direct) * 4 + c] * 8.0 / 256.0;
                    colors[c] += data[(i - 1) * width * 4 + (j + 1 * direct) * 4 + c] * 32.0 / 256.0;
                    colors[c] += data[(i - 1) * width * 4 + (j + 2 * direct) * 4 + c] * 8.0 / 256.0;

                    colors[c] += data[(i - 2 * direct) * width * 4 + (j + 1 * direct) * 4 + c] * 16.0 / 256.0;
                    colors[c] += data[(i - 2 * direct) * width * 4 + (j + 2 * direct) * 4 + c] * 4.0 / 256.0;
                }
                else
                {
                    cout << "wrong" << endl;
                }

            }

            newData[i * width * 4 + j * 4] = colors[0];
            newData[i * width * 4 + j * 4 + 1] = colors[1];
            newData[i * width * 4 + j * 4 + 2] = colors[2];
        }
    }

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            data[i * width * 4 + j * 4] = newData[i * width * 4 + j * 4];
            data[i * width * 4 + j * 4 + 1] = newData[i * width * 4 + j * 4 + 1];
            data[i * width * 4 + j * 4 + 2] = newData[i * width * 4 + j * 4 + 2];
        }
    }

    return true;
}// Filter_Gaussian

///////////////////////////////////////////////////////////////////////////////
//
//      Perform NxN Gaussian filter on this image.  Return success of 
//  operation.
//
///////////////////////////////////////////////////////////////////////////////

bool TargaImage::Filter_Gaussian_N( unsigned int N )
{
   ClearToBlack();
   return false;
}// Filter_Gaussian_N


///////////////////////////////////////////////////////////////////////////////
//
//      Perform 5x5 edge detect (high pass) filter on this image.  Return 
//  success of operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::Filter_Edge()
{
    unsigned char* newData;
    newData = new unsigned char[width * height * 4];
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            newData[i * width * 4 + j * 4] = data[i * width * 4 + j * 4];
            newData[i * width * 4 + j * 4 + 1] = data[i * width * 4 + j * 4 + 1];
            newData[i * width * 4 + j * 4 + 2] = data[i * width * 4 + j * 4 + 2];
        }
    }

    Filter_Gaussian();
    unsigned char* change;
    change = new unsigned char[width * height * 4];

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            change[i * width * 4 + j * 4] = newData[i * width * 4 + j * 4] - data[i * width * 4 + j * 4] > 0 ? newData[i * width * 4 + j * 4] - data[i * width * 4 + j * 4] : 0;
            change[i * width * 4 + j * 4 + 1] = newData[i * width * 4 + j * 4 + 1] - data[i * width * 4 + j * 4 + 1] > 0 ? newData[i * width * 4 + j * 4 + 1] - data[i * width * 4 + j * 4 + 1] : 0;
            change[i * width * 4 + j * 4 + 2] = newData[i * width * 4 + j * 4 + 2] - data[i * width * 4 + j * 4 + 2] > 0 ? newData[i * width * 4 + j * 4 + 2] - data[i * width * 4 + j * 4 + 2] : 0;
        }
    }

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            data[i * width * 4 + j * 4] = change[i * width * 4 + j * 4];
            data[i * width * 4 + j * 4 + 1] = change[i * width * 4 + j * 4 + 1];
            data[i * width * 4 + j * 4 + 2] = change[i * width * 4 + j * 4 + 2];
        }
    }

    return true;
}// Filter_Edge


///////////////////////////////////////////////////////////////////////////////
//
//      Perform a 5x5 enhancement filter to this image.  Return success of 
//  operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::Filter_Enhance()
{
    unsigned char* newData;
    newData = new unsigned char[width * height * 4];
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            newData[i * width * 4 + j * 4] = data[i * width * 4 + j * 4];
            newData[i * width * 4 + j * 4 + 1] = data[i * width * 4 + j * 4 + 1];
            newData[i * width * 4 + j * 4 + 2] = data[i * width * 4 + j * 4 + 2];
        }
    }

    Filter_Edge();

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            data[i * width * 4 + j * 4] = newData[i * width * 4 + j * 4] + data[i * width * 4 + j * 4] < 255 ? newData[i * width * 4 + j * 4] + data[i * width * 4 + j * 4] : 255;
            data[i * width * 4 + j * 4 + 1] = newData[i * width * 4 + j * 4 + 1] + data[i * width * 4 + j * 4 + 1] < 255 ? newData[i * width * 4 + j * 4 + 1] + data[i * width * 4 + j * 4 + 1] : 255;
            data[i * width * 4 + j * 4 + 2] = newData[i * width * 4 + j * 4 + 2] + data[i * width * 4 + j * 4 + 2] < 255 ? newData[i * width * 4 + j * 4 + 2] + data[i * width * 4 + j * 4 + 2] : 255;
        }
    }
    return true;
}// Filter_Enhance


///////////////////////////////////////////////////////////////////////////////
//
//      Run simplified version of Hertzmann's painterly image filter.
//      You probably will want to use the Draw_Stroke funciton and the
//      Stroke class to help.
// Return success of operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::NPR_Paint()
{
    ClearToBlack();
    return false;
}



///////////////////////////////////////////////////////////////////////////////
//
//      Halve the dimensions of this image.  Return success of operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::Half_Size()
{
    unsigned char* newData;
    int newW = width / 2;
    int newH = height / 2;
    newData = new unsigned char[newW * newH * 4];

    vector<double> colors;
    colors.push_back(0.0);
    colors.push_back(0.0);
    colors.push_back(0.0);


    int h = 0;
    int w = 0;
    int n = 0;

    for (int i = 0; i < newH; i++)
    {
        for (int j = 0; j < newW; j++)
        {

            vector<double> colors;
            colors.push_back(0.0);
            colors.push_back(0.0);
            colors.push_back(0.0);

            for (int c = 0; c < 3; c++)
            {
                int place = i * width * 4 * 2 + j * 4 * 2;
                colors[c] += data[place + c] * 0.25;
                // up&down
                if (i >= 1 && i <= (height - 2))
                {
                    colors[c] += data[place + width * 4 + c] * 0.125;
                    colors[c] += data[place - width * 4 + c] * 0.125;
                }
                else
                {
                    int direct = i == 0 ? 1 : -1;
                    colors[c] += data[place + direct * width * 4 + c] * 0.25;
                }

                if (j >= 1 && j <= (width - 2))
                {
                    colors[c] += data[place + c + 4] * 0.125;
                    colors[c] += data[place + c - 4] * 0.125;
                }
                else
                {
                    int direct = j == 0 ? 1 : -1;
                    colors[c] += data[place + c + 4 * direct] * 0.25;
                }

                if (j >= 1 && j <= (width - 2) && i >= 1 && i <= (height - 2))
                {
                    colors[c] += data[place + c + 4] * 0.0625;
                    colors[c] += data[place + width * 4 + c + 4] * 0.0625;
                    colors[c] += data[place - width * 4 + c + 4] * 0.0625;
                    colors[c] += data[place - width * 4 + c - 4] * 0.0625;

                }

                else if (i == 0 && j >= 1 && j <= (width - 2) || i == (height - 1) && j >= 1 && j <= (width - 2))
                {
                    int direct = i == 0 ? 1 : -1;
                    // i + 1
                    colors[c] += data[place + direct * width * 4 + c + 4] * 0.125;
                    colors[c] += data[place + direct * width * 4 + c - 4] * 0.125;
                    // i + 2
                }

                else if (j == 0 && i >= 1 && i <= (height - 2) || j == (width - 1) && i >= 1 && i <= (height - 2))
                {
                    int direct = j == 0 ? 1 : -1;

                    colors[c] += data[place + width * 4 + c + 4 * direct] * 0.125;
                    colors[c] += data[place - width * 4 + c + 4 * direct] * 0.125;


                }

                else if (j == 0 && i == 0 || j == width - 1 && i == height - 1)
                {
                    int direct = j == 0 ? 1 : -1;
                    colors[c] += data[place + direct * width * 4 + c + 4 * direct] * 0.25;
                }
                else if (j == 0 && i == height - 1 || i == 0 && j == width - 1)
                {
                    int direct = j == 0 ? 1 : -1;
                    colors[c] += data[place - direct * width * 4 + c + 4 * direct] * 0.25;
                }
                else
                {
                    cout << "wrong" << endl;
                }

            }


            newData[i * newW * 4 + j * 4] = colors[0];
            newData[i * newW * 4 + j * 4 + 1] = colors[1];
            newData[i * newW * 4 + j * 4 + 2] = colors[2];
        }
    }







    // change the size
    height /= 2;
    width /= 2;
    

    for (int i = 0; i < newH; i++)
    {
        for (int j = 0; j < newW; j++)
        {
            data[i * newW * 4 + j * 4] = newData[i * newW * 4 + j * 4];
            data[i * newW * 4 + j * 4 + 1] = newData[i * newW * 4 + j * 4 + 1];
            data[i * newW * 4 + j * 4 + 2] = newData[i * newW * 4 + j * 4 + 2];
        }
    }
    

    return true;
}// Half_Size


///////////////////////////////////////////////////////////////////////////////
//
//      Double the dimensions of this image.  Return success of operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::Double_Size()
{

    /*
    int newHeight = height * 2;
    int newWidth = width * 2;

    unsigned char* newData;
    newData = new unsigned char[newWidth * newHeight * 4];

    for (int i = 0; i < height; i+2)
    {
        for (int j = 0; j < width; j+2)
        {
            for (int k = 0; k < 2; k++)
            {
                newData[i * newWidth * 4 + j * 4 + k] = data[i * width * 4 + j * 4 + k];
                newData[i * newWidth * 4 + j * 4 + k + 4] = data[i * width * 4 + j * 4 + k];
                newData[i * newWidth * 4 + (j + 1) * 4 + k] = data[i * width * 4 + j * 4 + k];
                newData[i * newWidth * 4 + (j + 1) * 4 + k + 4] = data[i * width * 4 + j * 4 + k];
            }
        }
    }

    data = new unsigned char[newWidth * newHeight * 4];

    height *= 2;
    width *= 2;

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            for (int k = 0; k < 2; k++)
            {
                newData[i * newWidth * 4 + j * 4 + k] = data[i * width * 4 + j * 4 + k];
            }
        }
    }
    //data = newData;
    
*/

    unsigned char* newData;
    int newW = width * 2;
    int newH = height * 2;
    newData = new unsigned char[newW * newH * 4];

    int h = 0;
    int w = 0;
    int n = 0;

    for (int i = 0; i < newH; i++)
    {
        for (int j = 0; j < newW; j++)
        {
            newData[i * newW * 4 + j * 4] = data[i * width * 4 * 2 + j * 4 * 2];
            newData[i * newW * 4 + j * 4 + 1] = data[i * width * 4 * 2 + j * 4 * 2 + 1];
            newData[i * newW * 4 + j * 4 + 2] = data[i * width * 4 * 2 + j * 4 * 2 + 2];
        }
    }

    height /= 2;
    width /= 2;


    for (int i = 0; i < newH; i++)
    {
        for (int j = 0; j < newW; j++)
        {
            data[i * newW * 4 + j * 4] = newData[i * newW * 4 + j * 4];
            data[i * newW * 4 + j * 4 + 1] = newData[i * newW * 4 + j * 4 + 1];
            data[i * newW * 4 + j * 4 + 2] = newData[i * newW * 4 + j * 4 + 2];
        }
    }






    //ClearToBlack();
    return true;
}// Double_Size


///////////////////////////////////////////////////////////////////////////////
//
//      Scale the image dimensions by the given factor.  The given factor is 
//  assumed to be greater than one.  Return success of operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::Resize(float scale)
{
    ClearToBlack();

    //Scale(src, dst, sx, sy) :
    //    float w = max(1.0 / sx, 1.0 / sy);
    //for (int x = 0; x < xmax; x++) {
    //    for (int y = 0; y < ymax; y++) {
    //        float u = x / sx;
    //        float v = y / sy;
    //        dst(x, y) = resample_src(u, v, w);
    //    }
    //}

    return false;
}// Resize


//////////////////////////////////////////////////////////////////////////////
//
//      Rotate the image clockwise by the given angle.  Do not resize the 
//  image.  Return success of operation.
//
///////////////////////////////////////////////////////////////////////////////
bool TargaImage::Rotate(float angleDegrees)
{
    ClearToBlack();

    /*Rotate(src, dst, theta) :
        for (int x = 0; x < xmax; x++) {
            for (int y = 0; y < ymax; y++) {
                float u = x * cos(-Q) - y * sin(-Q);
                float u = x * sin(-Q) + y * cos(-Q);
                dst(x, y) = resample_src(u, v, w);
            }
        }*/
    return false;
}// Rotate


//////////////////////////////////////////////////////////////////////////////
//
//      Given a single RGBA pixel return, via the second argument, the RGB
//      equivalent composited with a black background.
//
///////////////////////////////////////////////////////////////////////////////
void TargaImage::RGBA_To_RGB(unsigned char *rgba, unsigned char *rgb)
{
    const unsigned char	BACKGROUND[3] = { 0, 0, 0 };

    unsigned char  alpha = rgba[3];

    if (alpha == 0)
    {
        rgb[0] = BACKGROUND[0];
        rgb[1] = BACKGROUND[1];
        rgb[2] = BACKGROUND[2];
    }
    else
    {
	    float	alpha_scale = (float)255 / (float)alpha;
	    int	val;
	    int	i;

	    for (i = 0 ; i < 3 ; i++)
	    {
	        val = (int)floor(rgba[i] * alpha_scale);
	        if (val < 0)
		    rgb[i] = 0;
	        else if (val > 255)
		    rgb[i] = 255;
	        else
		    rgb[i] = val;
	    }
    }
}// RGA_To_RGB


///////////////////////////////////////////////////////////////////////////////
//
//      Copy this into a new image, reversing the rows as it goes. A pointer
//  to the new image is returned.
//
///////////////////////////////////////////////////////////////////////////////
TargaImage* TargaImage::Reverse_Rows(void)
{
    unsigned char   *dest = new unsigned char[width * height * 4];
    TargaImage	    *result;
    int 	        i, j;

    if (! data)
    	return NULL;

    for (i = 0 ; i < height ; i++)
    {
	    int in_offset = (height - i - 1) * width * 4;
	    int out_offset = i * width * 4;

	    for (j = 0 ; j < width ; j++)
        {
	        dest[out_offset + j * 4] = data[in_offset + j * 4];
	        dest[out_offset + j * 4 + 1] = data[in_offset + j * 4 + 1];
	        dest[out_offset + j * 4 + 2] = data[in_offset + j * 4 + 2];
	        dest[out_offset + j * 4 + 3] = data[in_offset + j * 4 + 3];
        }
    }

    result = new TargaImage(width, height, dest);
    delete[] dest;
    return result;
}// Reverse_Rows


///////////////////////////////////////////////////////////////////////////////
//
//      Clear the image to all black.
//
///////////////////////////////////////////////////////////////////////////////
void TargaImage::ClearToBlack()
{
    memset(data, 0, width * height * 4);
}// ClearToBlack


///////////////////////////////////////////////////////////////////////////////
//
//      Helper function for the painterly filter; paint a stroke at
// the given location
//
///////////////////////////////////////////////////////////////////////////////
void TargaImage::Paint_Stroke(const Stroke& s) {
   int radius_squared = (int)s.radius * (int)s.radius;
   for (int x_off = -((int)s.radius); x_off <= (int)s.radius; x_off++) {
      for (int y_off = -((int)s.radius); y_off <= (int)s.radius; y_off++) {
         int x_loc = (int)s.x + x_off;
         int y_loc = (int)s.y + y_off;
         // are we inside the circle, and inside the image?
         if ((x_loc >= 0 && x_loc < width && y_loc >= 0 && y_loc < height)) {
            int dist_squared = x_off * x_off + y_off * y_off;
            if (dist_squared <= radius_squared) {
               data[(y_loc * width + x_loc) * 4 + 0] = s.r;
               data[(y_loc * width + x_loc) * 4 + 1] = s.g;
               data[(y_loc * width + x_loc) * 4 + 2] = s.b;
               data[(y_loc * width + x_loc) * 4 + 3] = s.a;
            } else if (dist_squared == radius_squared + 1) {
               data[(y_loc * width + x_loc) * 4 + 0] = 
                  (data[(y_loc * width + x_loc) * 4 + 0] + s.r) / 2;
               data[(y_loc * width + x_loc) * 4 + 1] = 
                  (data[(y_loc * width + x_loc) * 4 + 1] + s.g) / 2;
               data[(y_loc * width + x_loc) * 4 + 2] = 
                  (data[(y_loc * width + x_loc) * 4 + 2] + s.b) / 2;
               data[(y_loc * width + x_loc) * 4 + 3] = 
                  (data[(y_loc * width + x_loc) * 4 + 3] + s.a) / 2;
            }
         }
      }
   }
}


///////////////////////////////////////////////////////////////////////////////
//
//      Build a Stroke
//
///////////////////////////////////////////////////////////////////////////////
Stroke::Stroke() {}

///////////////////////////////////////////////////////////////////////////////
//
//      Build a Stroke
//
///////////////////////////////////////////////////////////////////////////////
Stroke::Stroke(unsigned int iradius, unsigned int ix, unsigned int iy,
               unsigned char ir, unsigned char ig, unsigned char ib, unsigned char ia) :
   radius(iradius),x(ix),y(iy),r(ir),g(ig),b(ib),a(ia)
{
}

